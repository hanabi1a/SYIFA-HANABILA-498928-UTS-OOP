import static sun.java2d.pipe.PixelToParallelogramConverter.len;

public class KTP {

    String nama;
    String telefon;
    String tgl_lahir;

    public KTP(String nama, String telefon, String tgl_lahir) {
        this.nama = nama;
        this.telefon = telefon;
        this.tgl_lahir = tgl_lahir;
    }

    public void setTelefon(String telefon) {
        int a = 12;
        int b = len(telefon);
        if a == b:
            return telefon;
    }

    private int len(String telefon) {
        return 0;
    }

    public void setTgl_lhr(String[] strings) {
    }
}
