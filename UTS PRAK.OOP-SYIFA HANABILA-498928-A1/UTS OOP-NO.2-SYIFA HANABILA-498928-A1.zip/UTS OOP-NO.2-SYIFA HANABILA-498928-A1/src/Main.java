public class Main {
    public static void main(String[] args) {

        KTP a = new KTP("Alif");
        System.out.println(a);
        a.setTelefon("1812333333333");
        System.out.println(a);
        a.setTelefon("081229106488");
        System.out.println(a);
        a.setTgl_lhr(new String[]{"30", "1", "2024"});
        System.out.println(a);


    }
}