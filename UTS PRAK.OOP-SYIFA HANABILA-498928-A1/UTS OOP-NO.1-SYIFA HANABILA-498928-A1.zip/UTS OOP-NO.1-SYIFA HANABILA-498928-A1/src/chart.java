import java.util.Arrays;

public class chart extends subject{

    Arrays sbeban;

    public chart(int beban, String nama, Arrays sbeban) {
        super(beban, nama);
        this.sbeban = sbeban;
    }
    
    public void totalsbeban(Arrays sbeban){
        this.sbeban = beban;
    }
    public Arrays addChart(int beban, String nama){
        addChart() [] = new subject;
    }

}
