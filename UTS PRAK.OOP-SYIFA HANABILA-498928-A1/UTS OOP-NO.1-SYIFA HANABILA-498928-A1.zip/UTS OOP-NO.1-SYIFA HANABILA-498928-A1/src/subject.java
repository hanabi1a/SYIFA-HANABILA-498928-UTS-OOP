public class subject {
    int beban;
    String nama;

    public subject(int beban, String nama) {
        this.beban = beban;
        this.nama = nama;
    }

}
