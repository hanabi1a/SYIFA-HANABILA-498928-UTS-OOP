//UTS OOP-NO.3-SYIFA HANABILA-498928-A1
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}