public class Burung extends Enemy {
    public Burung(String name, int hp, int attackDamage) {
        super(name, hp, attackDamage);
    }

    public String fly(){
        return "tinggi/rendah";
    }

    public String walk(){
        return "maju/mundur";
    }

    @Override
    public String toString() {
        return "Burung{}";
    }
}
