public class Pocong extends Enemy{
    public Pocong(String name, int hp, int attackDamage) {
        super(name, hp, attackDamage);
    }

    public String jump(){
        return "lompat";
    }
}
