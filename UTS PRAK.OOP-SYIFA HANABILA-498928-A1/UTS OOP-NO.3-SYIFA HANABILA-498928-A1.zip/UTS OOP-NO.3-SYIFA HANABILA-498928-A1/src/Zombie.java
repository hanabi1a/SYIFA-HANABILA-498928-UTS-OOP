public class Zombie extends Enemy{
    public Zombie(String name, int hp, int attackDamage) {
        super(name, hp, attackDamage);
    }

    public String walk(){
        return "maju/mundur";
    }

    @Override
    public String toString() {
        return "Zombie{}";
    }
}
